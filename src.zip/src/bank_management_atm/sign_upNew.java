package bank_management_atm;

import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.WindowConstants;

public class sign_upNew extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			@Override
			public void run() {
				try {
					sign_upNew frame = new sign_upNew();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public sign_upNew() {
		setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
		setLayout(null);
		contentPane = new JPanel();

		setContentPane(contentPane);

		JLabel application_form = new JLabel("application number is ");
		application_form.setBounds(50,30,500,100);
		contentPane.add(application_form);

		JLabel main_text = new JLabel("SIGN UP");
		main_text.setBounds(650,45,300,100);
		main_text.setBackground(new Color(0, 64, 128));
		contentPane.add(main_text);
	}

}
