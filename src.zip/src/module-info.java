/**
 *
 */
/**
 *
 */
module Bank_Management {
	requires java.desktop;
	requires java.sql;
	requires jcalendar.tz;
	requires mysql.connector.java;
}